<?php

$res = "1920x1080(1080p)";

$res = explode("(", $res)[0];
$res = explode("x", $res);
var_dump($res);

$switch = '0';
var_dump($switch ? true : false);


var_dump(explode("\t", "5.5G	/media/disk/videos/2019-10-03_03_12_32__resource_mode/课程_1_0.mp4↵")[0]);



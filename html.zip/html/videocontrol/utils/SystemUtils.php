<?php
/**
 * Created by PhpStorm.
 * User: 10324
 * Date: 2018/4/10
 * Time: 20:54
 */

class SystemUtils
{
    static function getIpInfo()
    {

    }

}